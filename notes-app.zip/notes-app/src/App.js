import { useState, useEffect } from "react";
import "./styles.css";

export default function App() {
  const [notes, setNotes] = useState(() => {
    const saved = localStorage.getItem("notes");
    if (saved) return JSON.parse(saved);

    return [{ id: 1, text: "Это ваша первая заметка ✨" }];
  });

  const [currentId, setCurrentId] = useState(notes[0].id);

  useEffect(() => {
    localStorage.setItem("notes", JSON.stringify(notes));
  }, [notes]);

  const currentNote = notes.find((n) => n.id === currentId);

  function addNote() {
    const newNote = { id: Date.now(), text: "" };
    setNotes([newNote, ...notes]);
    setCurrentId(newNote.id);
  }

  function updateNote(text) {
    setNotes(notes.map((n) => (n.id === currentId ? { ...n, text } : n)));
  }

  function deleteNote(id) {
    const filtered = notes.filter((n) => n.id !== id);
    setNotes(filtered);
    if (filtered.length > 0) setCurrentId(filtered[0].id);
  }

  return (
    <div className="app">
      <div className="sidebar">
        <h2>Заметки</h2>
        <button onClick={addNote}>Новая заметка</button>

        {notes.map((note) => (
          <div
            key={note.id}
            className={`note-item ${note.id === currentId ? "active" : ""}`}
            onClick={() => setCurrentId(note.id)}
          >
            {note.text.slice(0, 20) || "Пусто"}
            <button
              onClick={(e) => {
                e.stopPropagation();
                deleteNote(note.id);
              }}
            >
              ✖
            </button>
          </div>
        ))}
      </div>

      <textarea
        className="editor"
        value={currentNote?.text || ""}
        onChange={(e) => updateNote(e.target.value)}
        placeholder="Введите текст..."
      />
    </div>
  );
}
